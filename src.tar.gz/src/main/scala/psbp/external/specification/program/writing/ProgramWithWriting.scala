// package psbp.external.specification.program.writing

// import psbp.external.specification.program.Program

// import psbp.external.specification.writing.{
//   Writable
//   , Writing
// }

// trait ProgramWithWriting[W: Writable, >-->[- _, + _]] 
//   extends Program[>-->] 
//   , Writing[W, >-->]