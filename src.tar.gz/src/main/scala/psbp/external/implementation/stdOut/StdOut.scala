package psbp.external.implementation.stdOut

case class StdOut(effect: Unit => Unit)