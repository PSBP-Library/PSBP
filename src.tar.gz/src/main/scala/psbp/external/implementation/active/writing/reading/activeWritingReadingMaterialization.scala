package psbp.external.implementation.active.writing.reading

import psbp.external.specification.writing.Writable

import psbp.external.specification.materialization.Materialization

import psbp.external.implementation.active.writing.ActiveWriting

import psbp.external.implementation.active.writing.`=>AW`

import psbp.external.implementation.active.writing.reading.`=>AWR`

import psbp.external.implementation.active.writing.reading.ActiveWritingReading

import psbp.internal.specification.computation.Computation

import psbp.external.implementation.active.writing.{
  given Computation[ActiveWriting[?]]
}  

import psbp.external.implementation.active.writing.{
  given Materialization[`=>AW`[?], Unit, (?, Unit)]
}

import psbp.internal.implementation.computation.transformation.reading.readingTransformedMaterialization

given [
  W: Writable
  , R
]: Materialization[
  `=>AWR`[W, R]
  , Unit
  , R ?=> (W, Unit)
] with 

  type `=>AWR[W,R]` = [Z, Y] =>> Z => ActiveWritingReading[W, R][Y]
    
  override val materialize: (Unit `=>AWR[W,R]` Unit) => Unit ?=> R ?=> (W, Unit) =        
    `u=>awru` => 
      readingTransformedMaterialization.materialize(`u=>awru`) match {
        case (w, (_, u)) => (w, u)
      }

