package examples.implementation.pleaseTypeAnInteger

given Unit = 
  println("Please type an integer")
