package examples.implementation.stdIn

import psbp.external.implementation.stdIn.stdInBigInt.effect

given BigInt = 
  effect(())
